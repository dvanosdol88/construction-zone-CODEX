import { create } from 'zustand';

export type Category = 'Experience' | 'Ops' | 'Marketing' | 'Logic';

export interface Idea {
    id: string;
    text: string;
    category: Category;
    // NEW: Allows us to filter by specific page (e.g., 'Onboarding')
    subcategory: string; 
    timestamp: number;
    refined?: boolean;
    type: 'idea' | 'question';
    notes: { id: string; text: string; timestamp: number }[];
}

interface IdeaStore {
    ideas: Idea[];
    addIdea: (idea: Idea) => void;
    updateIdea: (id: string, updates: Partial<Idea>) => void;
    removeIdea: (id: string) => void;
}

// Seed data to show off your new structure
const SEED_DATA: Idea[] = [
    {
        id: '1',
        text: "Draft the 'Zero-Entry' upload flow for brokerage PDFs",
        category: 'Experience',
        subcategory: 'Onboarding',
        timestamp: Date.now(),
        type: 'idea',
        refined: false,
        notes: []
    },
    {
        id: '2',
        text: "Script the 'Dream Retirement' opening question",
        category: 'Experience',
        subcategory: 'First Meeting',
        timestamp: Date.now(),
        type: 'idea',
        refined: false,
        notes: []
    }
];

export const useIdeaStore = create<IdeaStore>((set) => ({
    ideas: SEED_DATA,
    addIdea: (idea) => set((state) => ({ ideas: [...state.ideas, idea] })),
    updateIdea: (id, updates) =>
        set((state) => ({
            ideas: state.ideas.map((idea) =>
                idea.id === id ? { ...idea, ...updates } : idea
            ),
        })),
    removeIdea: (id) =>
        set((state) => ({ ideas: state.ideas.filter((i) => i.id !== id) })),
}));