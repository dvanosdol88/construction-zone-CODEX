import React, { useState, useMemo } from 'react';
import { useIdeaStore, Category, Idea } from './ideaStore';
import { Search, Plus, Sparkles, CheckCircle, Circle, MessageSquare } from 'lucide-react';

// --- Configuration: Your RIA Architecture ---
const STRUCTURE: Record<Category, { emoji: string; label: string; pages: string[] }> = {
  Experience: {
    emoji: '✨',
    label: 'Client Experience',
    pages: ['Onboarding', 'First Meeting', 'Year 1', 'Portal Design']
  },
  Ops: {
    emoji: '⚙️',
    label: 'Ops & Tech',
    pages: ['Tech Stack', 'Compliance', 'Workflow Automation']
  },
  Marketing: {
    emoji: '🚀',
    label: 'Growth Engine',
    pages: ['Landing Page', 'Postcards', 'Fee Calculator', 'Messaging']
  },
  Logic: {
    emoji: '🧠',
    label: 'Advisory Logic',
    pages: ['Asset Allocation', 'Models', 'Research', 'Regulatory']
  }
};

export default function ConstructionZone() {
  const { ideas, addIdea, updateIdea } = useIdeaStore();
  
  // Navigation State
  const [activeTab, setActiveTab] = useState<Category>('Experience');
  const [activePage, setActivePage] = useState<string>(STRUCTURE['Experience'].pages[0]);
  
  // UI State
  const [searchQuery, setSearchQuery] = useState('');
  const [geminiOpen, setGeminiOpen] = useState(false);
  const [newItemText, setNewItemText] = useState('');

  // Update sidebar pages when top tab changes
  const handleTabChange = (tab: Category) => {
    setActiveTab(tab);
    // Automatically select the first page of the new tab
    setActivePage(STRUCTURE[tab].pages[0]);
  };

  // Filter Content based on Tab + Page + Search
  const filteredItems = useMemo(() => {
    return ideas.filter(idea => {
      const matchesContext = idea.category === activeTab && idea.subcategory === activePage;
      const matchesSearch = idea.text.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesContext && matchesSearch;
    });
  }, [ideas, activeTab, activePage, searchQuery]);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemText.trim()) return;
    addIdea({
      id: crypto.randomUUID(),
      text: newItemText,
      category: activeTab,
      subcategory: activePage,
      timestamp: Date.now(),
      type: 'idea',
      notes: []
    });
    setNewItemText('');
  };

  return (
    <div className="h-screen flex flex-col bg-white text-slate-800 font-sans">
      
      {/* 1. TOP NAVIGATION (The Domains) */}
      <header className="bg-slate-900 text-white px-6 py-0 flex items-center justify-between shadow-md z-20">
        <div className="flex items-center gap-8 overflow-x-auto no-scrollbar">
          <div className="font-bold text-lg py-4 pr-4 border-r border-slate-700 whitespace-nowrap">
            🚧 RIA Builder
          </div>
          {/* Top Tabs */}
          <div className="flex gap-1">
            {(Object.keys(STRUCTURE) as Category[]).map((key) => (
              <button
                key={key}
                onClick={() => handleTabChange(key)}
                className={`px-4 py-4 text-sm font-medium transition-colors border-b-4 ${
                  activeTab === key 
                    ? 'border-blue-500 text-white bg-slate-800' 
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span className="mr-2">{STRUCTURE[key].emoji}</span>
                {STRUCTURE[key].label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4 py-2">
           {/* Global Search */}
           <div className="relative">
            <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search everything..." 
              className="bg-slate-800 border-none rounded-full pl-9 pr-4 py-2 text-sm text-white placeholder-slate-400 focus:ring-1 focus:ring-blue-500 w-64 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {/* Gemini Toggle */}
          <button 
            onClick={() => setGeminiOpen(!geminiOpen)}
            className={`p-2 rounded-full transition-colors ${
              geminiOpen ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* 2. MAIN LAYOUT */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT SIDEBAR (The Subcategories) */}
        <nav className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col pt-6 pb-4 overflow-y-auto">
          <div className="px-6 mb-4 text-xs font-bold text-gray-400 uppercase tracking-wider">
            {STRUCTURE[activeTab].label}
          </div>
          <div className="space-y-1 px-3">
            {STRUCTURE[activeTab].pages.map(page => (
              <button
                key={page}
                onClick={() => setActivePage(page)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  activePage === page
                    ? 'bg-white shadow-sm text-blue-700 border border-gray-200'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {page}
              </button>
            ))}
          </div>
          
          <div className="mt-auto px-6 pt-6 border-t mx-3">
            <div className="text-xs text-gray-400 mb-2">Build Stats</div>
            <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
               <div className="h-full bg-blue-500 w-1/4"></div>
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Setup</span>
              <span>25%</span>
            </div>
          </div>
        </nav>

        {/* CENTER CONTENT (The Page) */}
        <main className="flex-1 overflow-y-auto bg-white p-8 md:p-12">
          <div className="max-w-3xl mx-auto">
            
            {/* Page Header */}
            <div className="mb-8 border-b pb-4">
               <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
                 {activePage}
               </h1>
               <p className="text-gray-500 mt-2">
                 Define the {activePage.toLowerCase()} logic and requirements here.
               </p>
            </div>

            {/* The List of Ideas/Blocks */}
            <div className="space-y-4 min-h-[300px]">
              {filteredItems.map(idea => (
                <div key={idea.id} className="group relative pl-4 border-l-2 border-gray-200 hover:border-blue-400 transition-colors py-1">
                   {/* Refine/Done Toggle */}
                   <button 
                     onClick={() => updateIdea(idea.id, { refined: !idea.refined })}
                     className="absolute -left-[9px] top-2 bg-white text-gray-300 hover:text-green-500 transition-colors"
                   >
                     {idea.refined ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Circle className="w-4 h-4" />}
                   </button>
                   
                   <div className={`${idea.refined ? 'opacity-50 line-through decoration-gray-300' : ''}`}>
                      <p className="text-lg text-slate-800">{idea.text}</p>
                      {idea.notes.length > 0 && (
                        <div className="mt-2 space-y-1">
                          {idea.notes.map(n => (
                            <div key={n.id} className="text-sm text-gray-500 bg-gray-50 p-2 rounded block">
                              {n.text}
                            </div>
                          ))}
                        </div>
                      )}
                   </div>
                </div>
              ))}

              {filteredItems.length === 0 && (
                <div className="text-gray-300 text-center py-12 italic">
                  No items yet. Start building {activePage}.
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="mt-8 pt-6 border-t sticky bottom-0 bg-white/95 backdrop-blur">
              <form onSubmit={handleAddItem} className="flex gap-3">
                <input 
                  autoFocus
                  type="text" 
                  placeholder={`Add a requirement or idea for ${activePage}...`}
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  value={newItemText}
                  onChange={(e) => setNewItemText(e.target.value)}
                />
                <button 
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" /> Add
                </button>
              </form>
            </div>

          </div>
        </main>

        {/* RIGHT GEMINI SIDEBAR */}
        {geminiOpen && (
          <aside className="w-[400px] border-l bg-white shadow-2xl z-30 flex flex-col animate-in slide-in-from-right duration-200">
            <div className="p-4 border-b flex justify-between items-center bg-blue-50">
              <h3 className="font-semibold text-blue-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600" /> Gemini Copilot
              </h3>
              <button onClick={() => setGeminiOpen(false)} className="text-blue-400 hover:text-blue-700">✕</button>
            </div>
            
            <div className="flex-1 p-4 bg-gray-50 overflow-y-auto">
               <div className="bg-white border p-4 rounded-lg shadow-sm text-sm text-gray-700 mb-4">
                  I'm context-aware. I know you're working on <strong>{activeTab} &gt; {activePage}</strong>.
                  <br/><br/>
                  Try asking: "Draft an email for the {activePage} step."
               </div>
            </div>

            <div className="p-4 bg-white border-t">
              <div className="relative">
                <textarea 
                  className="w-full border rounded-lg p-3 pr-10 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none h-24"
                  placeholder="Ask Gemini..."
                ></textarea>
                <button className="absolute bottom-3 right-3 p-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                  <MessageSquare className="w-4 h-4" />
                </button>
              </div>
            </div>
          </aside>
        )}

      </div>
    </div>
  );
}